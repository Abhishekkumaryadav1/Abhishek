// put the class name into the variable
const addBtn = document.querySelector(".add");
//    put the whole form into the variable
const input = document.querySelector(".parentform");

function addUser() {
    let div = document.createElement("div");
    div.className = "row mt-5";

    div.innerHTML = `
                    <div class="col">
                        <label for="exampleInputDegree" class="mb-2" id="degree">Degree</label>
                        <select class="form-select" aria-label="Default select example">
                            <option selected>Select</option>
                            <option value="1">B.Tech</option>
                            <option value="2">Pharamacy</option>
                            <option value="3">Diploma</option>
                            <option value="3">12TH</option>
                            <option value="3">10TH</option>
                          </select>
                    </div>
                    <div class="col">
                        <label for="exampleInputSchoolCollege" class="mb-2" id="school">Institute Name</label>
                        <input type="text" class="form-control" required>
                    </div>
                    <div class="col">
                        <label for="exampleInputStartedYear" class="mb-2" id="started">Started Date</label>
                        <input type="month" value="2001-01" class="form-control" required>
                    </div>
                    <div class="col">
                        <label for="exampleInputPassoutYear" class="mb-2">Passout Year</label>
                        <input type="month" class="form-control" value="2001-01" required>
                    </div>
                    <div class="col">
                        <label for="exampleInputPercentage" class="mb-2">Percentage</label>
                        <input type="number" class="form-control" placeholder="Do Not Write %" min="0" required>
                    </div>
                    <div class="col">
                        <label for="exampleInputBacklogs" class="mb-2 backlog">Backlogs</label>
                        <input type="number" class="form-control" placeholder="If Any" min="0" required>
                    </div>
                     <div class="col">
                        <button class=" btn btn-success float-end" onclick="Delete(this);" id="deletehover">Delete</button>
                     </div>
                    `

    input.appendChild(div);
}
    // add the eventlistner on button for click call
addBtn.addEventListener("click", addUser);
//    passing the variable to remove parentnode
function Delete(e) {
    e.parentNode.parentNode.remove();
}
